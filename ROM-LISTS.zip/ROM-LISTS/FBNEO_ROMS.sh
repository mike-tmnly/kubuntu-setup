#!/usr/bin/env bash
mkdir FBNEO/; cd FBNEO/

# DOWNLOAD CPS-1 ROMS #
mkdir CPS-1/; cd CPS-1/
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/ghouls.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/punisher.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/sf2.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/sf2ce.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/sf2hf.zip
cd ..
# DOWNLOAD CPS-2 ROMS #
mkdir CPS-2/; cd CPS-2/
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/mvsc.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/nwarr.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/sfa2.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/sfa3.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/sfz2al.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/ssf2.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/ssf2t.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/ssf2xj.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/vhunt2.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/vsav.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/vsav2.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/xmcota.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/xmvsf.zip
cd ..
# DOWNLOAD CPS-3 ROMS #
mkdir CPS-3/; cd CPS-3/
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/redearth.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/sfiii.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/sfiii2.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/sfiii3.zip
# DOWNLOAD OTHER ROMS #
mkdir OTHER/; cd OTHER/
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/mk2.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/simpsons.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/tmnt2.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/umk3.zip
cd ..; cd ..

# DOWNLOAD NEOGEO ROMS #
mkdir NEOGEO/; cd NEOGEO/
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/garou.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/kof2002.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/kof98.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/lastblad.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/lastbld2.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/matrim.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/mslug.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/mslug2.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/mslug3.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/mslug4.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/mslug5.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/mslugx.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/rotd.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/samsh5sp.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/samsho2.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/svc.zip
wget https://archive.org/download/fbnarcade-fullnonmerged/arcade/wakuwak7.zip
cd ..