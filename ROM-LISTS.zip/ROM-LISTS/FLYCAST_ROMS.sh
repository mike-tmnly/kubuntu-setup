#!/usr/bin/env bash
mkdir FLYCAST/; cd FLYCAST/

# DOWNLOAD ATOMISWAVE ROMS #
mkdir ATOMISWAVE/; cd ATOMISWAVE/
wget https://archive.org/download/mame-merged/mame-merged/dolphin.zip
wget https://archive.org/download/mame-merged/mame-merged/ggx15.zip
wget https://archive.org/download/mame-merged/mame-merged/kofxi.zip
wget https://archive.org/download/mame-merged/mame-merged/mslug6.zip
wget https://archive.org/download/mame-merged/mame-merged/ngbc.zip
wget https://archive.org/download/mame-merged/mame-merged/rumblef.zip
wget https://archive.org/download/mame-merged/mame-merged/rumblef2.zip
cd ..

# DOWNLOAD NAOMI ROMS #
mkdir NAOMI/; cd NAOMI/
wget https://archive.org/download/mame-merged/mame-merged/ausfache.zip
wget https://archive.org/download/mame-merged/mame-merged/cvs2.zip
wget https://archive.org/download/mame-merged/mame-merged/cvsgd.zip
wget https://archive.org/download/mame-merged/mame-merged/doa2m.zip
wget https://archive.org/download/mame-merged/mame-merged/ggxxac.zip
wget https://archive.org/download/mame-merged/mame-merged/mbaa.zip
wget https://archive.org/download/mame-merged/mame-merged/meltyb.zip
wget https://archive.org/download/mame-merged/mame-merged/meltybld.zip
wget https://archive.org/download/mame-merged/mame-merged/mvsc2.zip
wget https://archive.org/download/mame-merged/mame-merged/pjustic.zip
wget https://archive.org/download/mame-merged/mame-merged/sfz3ugd.zip
wget https://archive.org/download/mame-merged/mame-merged/vtennis2.zip
# DOWNLOAD NAOMI CHDS #
wget -r -nH --cut-dirs=2 --no-parent --reject="index.html*" -e robots=off \
https://archive.org/download/MAME_0.225_CHDs_merged/cvs2/
wget -r -nH --cut-dirs=2 --no-parent --reject="index.html*" -e robots=off \
https://archive.org/download/MAME_0.225_CHDs_merged/cvsgd/
wget -r -nH --cut-dirs=2 --no-parent --reject="index.html*" -e robots=off \
https://archive.org/download/MAME_0.225_CHDs_merged/ggxxac/
wget -r -nH --cut-dirs=2 --no-parent --reject="index.html*" -e robots=off \
https://archive.org/download/MAME_0.225_CHDs_merged/meltyb/
wget -r -nH --cut-dirs=2 --no-parent --reject="index.html*" -e robots=off \
https://archive.org/download/MAME_0.225_CHDs_merged/meltybld/
wget -r -nH --cut-dirs=2 --no-parent --reject="index.html*" -e robots=off \
https://archive.org/download/MAME_0.225_CHDs_merged/sfz3ugd/
cd ..

# DOWNLOAD DREAMCAST ROMS #
mkdir DREAMCAST/; cd DREAMCAST/
https://archive.org/download/chd_dc/CHD-Dreamcast/Atari%20Anniversary%20Edition%20%28USA%29.chd
https://archive.org/download/chd_dc/CHD-Dreamcast/Capcom%20vs.%20SNK%20-%20Millennium%20Fight%202000%20Pro%20%28Japan%29.chd
https://archive.org/download/chd_dc/CHD-Dreamcast/Capcom%20vs.%20SNK%202%20-%20Millionaire%20Fighting%202001%20%28Japan%29.chd
https://archive.org/download/chd_dc/CHD-Dreamcast/Marvel%20vs.%20Capcom%202%20%28USA%29.chd
https://archive.org/download/chd_dc/CHD-Dreamcast/Resident%20Evil%202%20%28USA%29%20%28Disc%201%29.chd
https://archive.org/download/chd_dc/CHD-Dreamcast/Resident%20Evil%202%20%28USA%29%20%28Disc%202%29.chd
https://archive.org/download/chd_dc/CHD-Dreamcast/Resident%20Evil%203%20-%20Nemesis%20%28USA%29.chd
cd ..